package com.example.studentmanagementsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MathsAdd extends AppCompatActivity {

    EditText facNum, name, course;
    Button add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maths_add);

        facNum = findViewById(R.id.facNum_edit2);
        name = findViewById(R.id.name_edit2);
        course = findViewById(R.id.course_edit2);
        add = findViewById(R.id.add_btn2);

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_student = database.getReference("Maths");

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                table_student.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int c = Integer.parseInt(course.getText().toString());

                        if (dataSnapshot.child(facNum.getText().toString()).exists()) {
                            Toast.makeText(MathsAdd.this, "Student already exists!", Toast.LENGTH_SHORT).show();
                        }
                        else if(c < 1 || c > 4){
                            Toast.makeText(MathsAdd.this, "Enter a valid course!", Toast.LENGTH_SHORT).show();
                        }
                        else if(facNum.getText().toString().equals("") || name.getText().toString().equals("") ||
                                course.getText().toString().equals("")){
                            Toast.makeText(MathsAdd.this, "All fields must be filled!", Toast.LENGTH_SHORT).show();
                        }

                        else {
                            Student stu = new Student(facNum.getText().toString(),
                                    name.getText().toString(),
                                    course.getText().toString()
                            );
                            table_student.child(facNum.getText().toString()).setValue(stu);
                            Toast.makeText(MathsAdd.this, "Student added", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });


    }
}
